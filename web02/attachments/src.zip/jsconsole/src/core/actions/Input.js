export const ADD_HISTORY = 'ADD_HISTORY';
export function addHistory(value) { return { type: ADD_HISTORY, value }; };
