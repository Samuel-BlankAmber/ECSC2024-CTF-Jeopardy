import React from 'react';
export default () => <div className="type undefined">undefined</div>;
