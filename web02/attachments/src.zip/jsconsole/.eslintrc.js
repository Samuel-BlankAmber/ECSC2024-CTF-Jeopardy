module.exports = Object.assign({}, require('@remy/eslint/cra'), {
});

// "extends": [
//   "plugin:prettier/recommended"
// ],
// "rules": {
//   "prettier/prettier": ["error", {
//     "arrowParens": "avoid",
//     "bracketSpacing": true,
//     "jsxBracketSameLine": false,
//     "parser": "babylon",
//     "printWidth": 80,
//     "proseWrap": "preserve",
//     "semi": true,
//     "singleQuote": true,
//     "tabWidth": 2,
//     "trailingComma": "es5",
//     "useTabs": false,
//   }]
// }
