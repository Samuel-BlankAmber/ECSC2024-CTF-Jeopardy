# Debugging

It is highly recommended to debug this challenge directly from the running
docker container to preserve the environment as much as possible.

Make sure to uncomment the appropriate lines in `Dockerfile` and
`docker-compose.yml` to install `gdbserver` within the container and run the
appropriate command to expose the debugging session.

Run the docker container so that the challenge is run through `gdbserver`, you
can then attach a debugging session using `pwntools`:

```python
gs = """
    catch load yap.cpython-312-x86_64-linux-gnu.so
    commands
        # Insert any breakpoint on the library here e.g.
        # b *PyInit_yap
        continue
    end
    continue
    """

io = remote("localhost", 1337)
gdb.attach(target=("localhost", 1338), exe="./python", gdbscript=gs)

# Use io to interact with the challenge

io.interactive()
```

> [!IMPORTANT]  
> Make sure to copy the `python` binary from the container to have the
> `gdb.attach()` function work properly. you can copy it with `docker cp
> yap-yap-1:/app/cpython/python .`
