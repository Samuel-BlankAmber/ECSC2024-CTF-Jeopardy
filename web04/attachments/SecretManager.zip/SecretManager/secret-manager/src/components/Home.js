 import React from 'react'

 const Home = () => {
   return (
     <div>
         <h1 className="my-3">Home</h1>
         <p className="my-3">
            Welcome to the secret manager! Here you can store all your secrets in a secure way.
            <br />
            I hope you payed for this :D
         </p>
     </div>
   )
 }

 export default Home